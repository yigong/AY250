Install:
1. direct to the directory contain setup.py
2. python setup.py install
Function:
This is a calculator. You can ask simple questions like algebras. You can also use it as an computational knowledge engine. 