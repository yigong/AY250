from distutils.core import setup
setup(name='calculator', version = '1.0',py_modules=['CalCalc'])